namespace dummy {
void base__macro_cc() {}
}  // namespace dummy
