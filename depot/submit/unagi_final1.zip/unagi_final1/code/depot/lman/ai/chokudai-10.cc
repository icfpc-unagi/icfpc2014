#include "lman/ai/chokudai-10.h"

namespace lman {
namespace chokudai_10 {
#include "lman/ai/chokudai-10.cpp"
}  // namespace chokudai_10
}  // namespace lman

