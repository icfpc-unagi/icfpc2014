#include "lman/ai/rounding.h"

namespace lman {
namespace rounding {
#include "lman/ai/rounding.cpp"
}  // namespace rounding
}  // namespace lman

