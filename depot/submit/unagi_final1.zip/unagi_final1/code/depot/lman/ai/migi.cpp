#include "translator/lib.h"

P init(P game, P nazo) {
  return top(0);
}

P step(P ai, P game) {
  return P(0, 1);
}
