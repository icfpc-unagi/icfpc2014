#include "lman/ai/chokudai-8.h"

namespace lman {
namespace chokudai_8 {
#include "lman/ai/chokudai-8.cpp"
}  // namespace chokudai_8
}  // namespace lman

