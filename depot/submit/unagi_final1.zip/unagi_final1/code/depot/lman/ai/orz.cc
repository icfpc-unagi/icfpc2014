#include "lman/ai/orz.h"

namespace lman {
namespace orz {
#include "lman/ai/orz.cpp"
}  // namespace orz
}  // namespace lman

