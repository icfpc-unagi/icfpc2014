#include "lman/ai/wata_cpp.h"

namespace lman {
namespace wata_cpp {
#include "lman/ai/wata_cpp.cpp"
}  // namespace wata_cpp
}  // namespace lman

