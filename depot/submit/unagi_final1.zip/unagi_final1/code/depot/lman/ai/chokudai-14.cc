#include "lman/ai/chokudai-14.h"

namespace lman {
namespace chokudai_14 {
#include "lman/ai/chokudai-14.cpp"
}  // namespace chokudai_14
}  // namespace lman

