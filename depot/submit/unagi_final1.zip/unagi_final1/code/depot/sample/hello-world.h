#ifndef SAMPLE_HELLO_WORLD_H_
#define SAMPLE_HELLO_WORLD_H_

bool HelloWorld();

#endif  // SAMPLE_HELLO_WORLD_H_
