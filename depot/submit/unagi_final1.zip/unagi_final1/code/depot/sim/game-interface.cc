#include "sim/game-interface.h"

namespace dummy {
void sim__game_interface_cc() {}
}  // namespace dummy
