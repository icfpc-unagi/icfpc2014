#include "ghost/ai/fichokudai.h"

namespace dummy {
void ghost_ai_fichokudai_cc() {}
}  // namespace dummy
