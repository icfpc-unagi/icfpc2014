#include "ghost/ai/iwi5.h"

namespace dummy {
void ghost_ai_iwi5_cc() {}
}  // namespace dummy
