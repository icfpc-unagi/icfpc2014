#include "ghost/ai/fickle_debug.h"

namespace dummy {
void ghost_ai_fickle_debug_cc() {}
}  // namespace dummy
