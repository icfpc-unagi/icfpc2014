#include "ghost/ai/sakichokudai.h"

namespace dummy {
void ghost_ai_sakichokudai_cc() {}
}  // namespace dummy
