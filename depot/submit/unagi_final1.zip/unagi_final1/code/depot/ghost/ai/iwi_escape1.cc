#include "ghost/ai/iwi_escape1.h"

namespace dummy {
void ghost_ai_iwi_escape1_cc() {}
}  // namespace dummy
