#include "ghost/ai/iwi3.h"

namespace dummy {
void ghost_ai_iwi3_cc() {}
}  // namespace dummy
