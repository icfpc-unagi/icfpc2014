#include "ghost/ai/iwi6.h"

namespace dummy {
void ghost_ai_iwi6_cc() {}
}  // namespace dummy
