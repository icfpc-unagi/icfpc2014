#include "ghost/ai/iwi4.h"

namespace dummy {
void ghost_ai_iwi4_cc() {}
}  // namespace dummy
