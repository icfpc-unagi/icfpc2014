#include "ghost/ai/fickle.h"

namespace dummy {
void ghost_ai_fickle_cc() {}
}  // namespace dummy
