namespace dummy {
void sbl__sbl_cc() {}
}  // namespace dummy
