namespace dummy {
void sim__lambda_man_interface_cc() {}
}  // namespace dummy
