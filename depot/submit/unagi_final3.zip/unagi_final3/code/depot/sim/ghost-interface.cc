namespace dummy {
void sim__ghost_interface_cc() {}
}  // namespace dummy
