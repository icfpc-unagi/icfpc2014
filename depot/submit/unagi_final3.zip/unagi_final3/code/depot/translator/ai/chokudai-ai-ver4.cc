#include "chokudai-ai-ver4.b"
