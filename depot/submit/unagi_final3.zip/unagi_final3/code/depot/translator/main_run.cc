#include "translator/lib.h"

void run();

int main(){
  run();
  return 0;
}
