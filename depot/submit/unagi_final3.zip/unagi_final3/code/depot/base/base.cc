namespace dummy {
void base__base_cc() {}
}  // namespace dummy
