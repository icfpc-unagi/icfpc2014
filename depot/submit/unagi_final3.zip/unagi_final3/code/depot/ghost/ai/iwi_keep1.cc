#include "ghost/ai/iwi_keep1.h"

namespace dummy {
void ghost_ai_iwi_keep1_cc() {}
}  // namespace dummy
