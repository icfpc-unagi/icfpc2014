#include "ghost/ai/iwi1.h"

namespace dummy {
void ghost_ai_iwi1_cc() {}
}  // namespace dummy
