#include "lman/ai/piyo.h"

namespace lman {
namespace piyo {
#include "lman/ai/piyo.cpp"
}  // namespace piyo
}  // namespace lman

