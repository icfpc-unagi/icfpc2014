#include "lman/ai/wata-10.h"

namespace lman {
namespace wata_10 {
#include "lman/ai/wata-10.cpp"
}  // namespace wata_10
}  // namespace lman

