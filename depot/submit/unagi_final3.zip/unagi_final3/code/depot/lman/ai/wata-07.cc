#include "lman/ai/wata-07.h"

namespace lman {
namespace wata_07 {
#include "lman/ai/wata-07.cpp"
}  // namespace wata_07
}  // namespace lman

