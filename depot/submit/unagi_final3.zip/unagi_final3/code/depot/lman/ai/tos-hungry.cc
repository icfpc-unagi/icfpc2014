#include "lman/ai/tos-hungry.h"

namespace lman {
namespace tos_hungry {
#include "lman/ai/tos-hungry.cpp"
}  // namespace tos_hungry
}  // namespace lman

