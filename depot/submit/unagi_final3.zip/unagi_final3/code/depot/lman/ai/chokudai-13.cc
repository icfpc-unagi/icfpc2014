#include "lman/ai/chokudai-13.h"

namespace lman {
namespace chokudai_13 {
#include "lman/ai/chokudai-13.cpp"
}  // namespace chokudai_13
}  // namespace lman

