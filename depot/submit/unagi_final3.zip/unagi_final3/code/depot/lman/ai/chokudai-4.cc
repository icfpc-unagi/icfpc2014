#include "lman/ai/chokudai-4.h"

namespace lman {
namespace chokudai_4 {
#include "lman/ai/chokudai-4.cpp"
}  // namespace chokudai_4
}  // namespace lman

