#include "lman/ai/chokudai-34.h"

namespace lman {
namespace chokudai_34 {
#include "lman/ai/chokudai-34.cpp"
}  // namespace chokudai_34
}  // namespace lman

