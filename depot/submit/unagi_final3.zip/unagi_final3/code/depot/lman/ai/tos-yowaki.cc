#include "lman/ai/tos-yowaki.h"

namespace lman {
namespace tos_yowaki {
#include "lman/ai/tos-yowaki.cpp"
}  // namespace tos_yowaki
}  // namespace lman

