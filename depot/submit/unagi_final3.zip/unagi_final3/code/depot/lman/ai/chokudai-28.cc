#include "lman/ai/chokudai-28.h"

namespace lman {
namespace chokudai_28 {
#include "lman/ai/chokudai-28.cpp"
}  // namespace chokudai_28
}  // namespace lman

