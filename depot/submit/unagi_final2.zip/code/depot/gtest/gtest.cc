namespace dummy {
void gtest__gtest_cc() {}
}  // namespace dummy
