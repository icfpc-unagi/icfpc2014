#include "lman/ai/chokudai-33.h"

namespace lman {
namespace chokudai_33 {
#include "lman/ai/chokudai-33.cpp"
}  // namespace chokudai_33
}  // namespace lman

