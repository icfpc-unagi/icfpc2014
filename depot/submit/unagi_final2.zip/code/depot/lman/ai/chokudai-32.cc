#include "lman/ai/chokudai-32.h"

namespace lman {
namespace chokudai_32 {
#include "lman/ai/chokudai-32.cpp"
}  // namespace chokudai_32
}  // namespace lman

