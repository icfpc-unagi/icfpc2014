#include "lman/ai/migi.h"

namespace lman {
namespace migi {
#include "lman/ai/migi.cpp"
}  // namespace migi
}  // namespace lman

