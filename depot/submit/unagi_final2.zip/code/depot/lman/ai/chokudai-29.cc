#include "lman/ai/chokudai-29.h"

namespace lman {
namespace chokudai_29 {
#include "lman/ai/chokudai-29.cpp"
}  // namespace chokudai_29
}  // namespace lman

