#include "lman/ai/tos-sokushi-kaihi.h"

namespace lman {
namespace tos_sokushi_kaihi {
#include "lman/ai/tos-sokushi-kaihi.cpp"
}  // namespace tos_sokushi_kaihi
}  // namespace lman

