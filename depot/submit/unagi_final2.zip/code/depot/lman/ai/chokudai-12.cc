#include "lman/ai/chokudai-12.h"

namespace lman {
namespace chokudai_12 {
#include "lman/ai/chokudai-12.cpp"
}  // namespace chokudai_12
}  // namespace lman

