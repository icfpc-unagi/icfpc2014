#include "lman/ai/chokudai-30.h"

namespace lman {
namespace chokudai_30 {
#include "lman/ai/chokudai-30.cpp"
}  // namespace chokudai_30
}  // namespace lman

