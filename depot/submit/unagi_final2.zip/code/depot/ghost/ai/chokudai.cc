#include "ghost/ai/chokudai.h"

namespace dummy {
void ghost_ai_chokudai_cc() {}
}  // namespace dummy
