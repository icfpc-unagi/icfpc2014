#include "ghost/ai/iwi2.h"

namespace dummy {
void ghost_ai_iwi2_cc() {}
}  // namespace dummy
