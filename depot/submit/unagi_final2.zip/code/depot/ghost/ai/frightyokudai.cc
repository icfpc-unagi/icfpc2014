#include "ghost/ai/frightyokudai.h"

namespace dummy {
void ghost_ai_frightyokudai_cc() {}
}  // namespace dummy
